import java.util.Scanner;

public class OrtaSeviyeExercises implements Exercises {
    private final String[] eslestirmeSorulari = {"Abroad", "Argue", "Future", "Island", "Prepare"};
    private final String[] dogruEslestirmeCevaplar = {"Yurt dışı", "Tartışmak", "Gelecek", "Ada", "Hazırlamak"};

    private final String[] boslukDoldurmaSorulari = {"spend", "aware", "began", "contacted", "considered"};
    private final String[] dogruBoslukDoldurmaCevaplar = {"harcamak", "farkında", "başladı", "iletişime geçti", "düşündü"};

    public void run() {
        eslestirmeExercise(eslestirmeSorulari, dogruEslestirmeCevaplar);
        boslukDoldurmaExercise(boslukDoldurmaSorulari, dogruBoslukDoldurmaCevaplar);
    }

    public void eslestirmeExercise(String[] sorular, String[] dogruCevaplar) {
        // Kullanıcıdan cevapları al ve doğru cevaplarla karşılaştır
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < sorular.length; i++) {
            System.out.print(sorular[i] + " = ");
            String cevap = scanner.nextLine();
            if (cevap.equalsIgnoreCase(dogruCevaplar[i])) {
                System.out.println("Doğru!");
            } else {
                System.out.println("Yanlış! Doğru cevap: " + dogruCevaplar[i]);
            }
        }
    }

    public void boslukDoldurmaExercise(String[] sorular, String[] dogruCevaplar) {
        // Kullanıcıdan cevapları al ve doğru cevaplarla karşılaştır
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < sorular.length; i++) {
            System.out.print(sorular[i] + " = ");
            String cevap = scanner.nextLine();
            if (cevap.equalsIgnoreCase(dogruCevaplar[i])) {
                System.out.println("Doğru!");
            } else {
                System.out.println("Yanlış! Doğru cevap: " + dogruCevaplar[i]);
            }
        }
    }
}
