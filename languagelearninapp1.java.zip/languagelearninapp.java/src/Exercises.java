public interface Exercises {
    void run();
}