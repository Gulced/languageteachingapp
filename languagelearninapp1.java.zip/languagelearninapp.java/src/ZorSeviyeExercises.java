import java.util.Scanner;

public class ZorSeviyeExercises implements Exercises {
    @Override
    public void run() {
        System.out.println("Zor seviye soruları");
    }

    public String[][] getEslestirmeExercise() {
        String[][] eslestirmeSorular = {
                {"Contribution"},
                {"Disapprove"},
                {"Fundamental"},
                {"Rapid"},
                {"Venture"}
        };

        return eslestirmeSorular;
    }

    public String[][] getBoslukDoldurmaExercise() {
        String[][] boslukDoldurmaSorular = {
                {"devote", "coverage", "trace", "assassinated"},
                {"The magazine then went on to ---- six full pages"},
                {"to the film and its background, unprecedented ------ for a film"},
                {"The film, which won no fewer than eight Oscars, ----- the life of Mahatma Gandhi"},
                {"Gandhi was ----- in 1948, at the age of 78"}
        };

        return boslukDoldurmaSorular;
    }

    public String[] cevaplarEslestirme() {
        String[][] eslestirmeSorular = getEslestirmeExercise();
        String[] cevaplar = new String[eslestirmeSorular.length];

        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < eslestirmeSorular.length; i++) {
            System.out.print(eslestirmeSorular[i][0] + " = ");
            cevaplar[i] = scanner.nextLine();
        }

        return cevaplar;
    }

    public String[] cevaplarBoslukDoldurma() {
        String[][] boslukDoldurmaSorular = getBoslukDoldurmaExercise();
        String[] cevaplar = new String[boslukDoldurmaSorular.length];

        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < boslukDoldurmaSorular.length; i++) {
            System.out.print(boslukDoldurmaSorular[i][0] + " = ");
            cevaplar[i] = scanner.nextLine();
        }

        return cevaplar;
    }

    public void compareAnswers() {
        String[] dogruEslestirmeCevaplar = {"DoğruCevap1", "DoğruCevap2", "DoğruCevap3", "DoğruCevap4", "DoğruCevap5"};
        String[] dogruBoslukDoldurmaCevaplar = {"DoğruCevap1", "DoğruCevap2", "DoğruCevap3", "DoğruCevap4", "DoğruCevap5"};

        String[] cevaplarEslestirme = cevaplarEslestirme();
        String[] cevaplarBoslukDoldurma = cevaplarBoslukDoldurma();

        // Eslestirme soruları için cevapları kontrol et
        for (int i = 0; i < cevaplarEslestirme.length; i++) {
            if (cevaplarEslestirme[i].equalsIgnoreCase(dogruEslestirmeCevaplar[i])) {
                System.out.println("Eslestirme Sorusu " + (i + 1) + " doğru!");
            } else {
                System.out.println("Eslestirme Sorusu " + (i + 1) + " yanlış! Doğru cevap: " + dogruEslestirmeCevaplar[i]);
            }
        }

        // Bosluk doldurma soruları için cevapları kontrol et
        for (int i = 0; i < cevaplarBoslukDoldurma.length; i++) {
            if (cevaplarBoslukDoldurma[i].equalsIgnoreCase(dogruBoslukDoldurmaCevaplar[i])) {
                System.out.println("BoslukDoldurma Sorusu " + (i + 1) + " doğru!");
            } else {
                System.out.println("BoslukDoldurma Sorusu " + (i + 1) + " yanlış! Doğru cevap: " + dogruBoslukDoldurmaCevaplar[i]);
            }
        }
    }
}
